<?php
if (isset($_GET['utm_source']) && $_GET['utm_source'] != '')
    setcookie('utm_source', $_GET['utm_source'], time()+60*60*24*60,'/');

if (isset($_GET['utm_term']) && $_GET['utm_term'] != '')
    setcookie('utm_term', $_GET['utm_term'], time()+60*60*24*60,'/');

/********************************************************/
?>



<html>

<!-- Mirrored from tolyatty.kvartir-remonty.ru/remont-kvartir-rassrochka/ by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 10 May 2017 17:23:36 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="yandex-verification" content="7ca45477c39a23bf" />

<link href="../js/fancybox/source/jquery.fancybox.css" rel="stylesheet">

<script src="../js/jquery-1.11.3.min.js"></script>
    
        
    <script src="../js/jquery.fancybox.pack.js"></script>
    <script language="JavaScript">

dayarray=new Array("воскресенье","понедельник","вторник","среда","четверг","пятница","суббота")
montharray=new Array ("января","февраля","марта","апреля","мая","июня","июля","августа","сентября","октебря","ноября","декабря")
ndata=new Date();
day=dayarray[ndata.getDay()];
month=montharray[ndata.getMonth()];
date=ndata.getDate();
year=ndata.getYear();
datastr=( month )

</script>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="robots" content="index, follow" />
<meta name="keywords" content="Ремонт квартиры в рассрочку. Ремонт в кредит." />
<meta name="description" content="Ремонт квартиры в рассрочку. Ремонт в кредит." />
<link href="../bitrix/cache/css/s1/main/kernel_main/kernel_mainf85d.css?149207081948075" type="text/css"  rel="stylesheet" />
<link href="../bitrix/cache/css/s1/main/page_2c01e545f051d40031c500ec29b79a6e/page_2c01e545f051d40031c500ec29b79a6e90e6.css?149207255134270" type="text/css"  rel="stylesheet" />
<script type="text/javascript">if(!window.BX)window.BX={message:function(mess){if(typeof mess=='object') for(var i in mess) BX.message[i]=mess[i]; return true;}};</script>
<script type="text/javascript">(window.BX||top.BX).message({'JS_CORE_LOADING':'Загрузка...','JS_CORE_NO_DATA':'- Нет данных -','JS_CORE_WINDOW_CLOSE':'Закрыть','JS_CORE_WINDOW_EXPAND':'Развернуть','JS_CORE_WINDOW_NARROW':'Свернуть в окно','JS_CORE_WINDOW_SAVE':'Сохранить','JS_CORE_WINDOW_CANCEL':'Отменить','JS_CORE_WINDOW_CONTINUE':'Продолжить','JS_CORE_H':'ч','JS_CORE_M':'м','JS_CORE_S':'с','JSADM_AI_HIDE_EXTRA':'Скрыть лишние','JSADM_AI_ALL_NOTIF':'Показать все','JSADM_AUTH_REQ':'Требуется авторизация!','JS_CORE_WINDOW_AUTH':'Войти','JS_CORE_IMAGE_FULL':'Полный размер'});</script>
<script type="text/javascript">(window.BX||top.BX).message({'LANGUAGE_ID':'ru','FORMAT_DATE':'DD.MM.YYYY','FORMAT_DATETIME':'DD.MM.YYYY HH:MI:SS','COOKIE_PREFIX':'BITRIX_SM','SERVER_TZ_OFFSET':'10800','SITE_ID':'s1','SITE_DIR':'/','USER_ID':'','SERVER_TIME':'1494435951','USER_TZ_OFFSET':'0','USER_TZ_AUTO':'Y','bitrix_sessid':'e905fc88b8902fce1040d9c2729a833a'});</script>



<script type="text/javascript">BX.setJSList(['/bitrix/js/main/core/core.js?147375411670993','../bitrix/js/main/core/core_ajaxb86b.js?147375411620978','../bitrix/js/main/json/json2.min79e0.js?14737541163467','../bitrix/js/main/core/core_ls50f8.js?14737541167365','../bitrix/js/main/sessionfb79.js?14737541183642','../bitrix/js/main/core/core_windowd9ed.js?147375411674917','../bitrix/js/main/core/core_popup8356.js?147375411631170','../bitrix/js/main/core/core_date32da.js?147375411634276','../bitrix/js/main/utils29fd.js?147375411830973','../bitrix/components/bitrix/map.yandex.view/templates/.default/scriptd971.js?14737541191540','../bitrix/templates/main/components/bitrix/news.list/map_city_slider/scriptfc7e.js?14918981129117','/bitrix/templates/main/components/bitrix/news.list/map_city_slider/swiper.min.js?148722444196165']); </script>
<script type="text/javascript">BX.setCSSList(['/bitrix/js/main/core/css/core.css?14737541162854','../bitrix/js/main/core/css/core_popup2c1b.css?147375411633075','../bitrix/js/main/core/css/core_dateddd0.css?14737541169689','../js/countdown/flipclock85da.css?14737541053968','../bitrix/templates/.default/components/bitrix/news/otzivi-mezhkomnatnie-dveri/bitrix/news.list/.default/style717e.css?1473754107150','../bitrix/components/bitrix/map.yandex.system/templates/.default/style972f.css?1473754120666','../bitrix/templates/main/components/bitrix/news.list/map_city_slider/style45eb.css?14893815725210','../bitrix/templates/main/components/bitrix/news.list/map_city_slider/swiper.min14e2.css?147658489417761','../bitrix/templates/main/components/bitrix/map.yandex.system/office_map/stylea1da.css?14915403484636','/bitrix/templates/.default/components/bitrix/news/primeri-glavnaya/bitrix/news.list/.default/style.css?1473754107150']); </script>


<script type="text/javascript" src="../bitrix/cache/js/s1/main/page_7c9e8d82d585619527e743aba5e92fbc/page_7c9e8d82d585619527e743aba5e92fbc2c84.js?1492072551107943"></script>


<link rel="shortcut icon" href="../favicon.ico" type="image/x-icon">

<link rel="stylesheet" href="../css/normalize.css"/>
<link rel="stylesheet" href="../css/fonts.css"/>
<link href="../css/style-old.css?2_2" rel="stylesheet">

<!-- Bootstrap -->
<link href="../css/bootstrap.min.css" rel="stylesheet">

<!-- ProdesCode -->

<link href="../css/media.css" rel="stylesheet">
<link href="../css/skin.css" rel="stylesheet">



<link href="../js/twentytwenty-master/twentytwenty.css" rel="stylesheet">


<link href="../css/stylef5eb.css?vrs_4" rel="stylesheet">




<script src="../js/twentytwenty-master/jquery.event.move.js"></script>
<script src="../js/twentytwenty-master/jquery.twentytwenty.js"></script>

<script src="../js/compile.js?1"></script>



<title>Ремонт квартиры в рассрочку. Ремонт в кредит.</title></head>

<body>
<?php
    /********************************************************/
?>

<div class="topclose5px"></div>
	<div id="tzloadding">
    <div id="loader-wrapper">
        <div id="loader"></div>
    </div>
</div><div id="panel"></div>
