<div class="es1 _main rassr_bg">
                <div class="container">
                    <div class="es1__pict"></div>
                    <div class="es1__block">
                        <h1>ШКАФ В РАССРОЧКУ БЕЗ <span>И ПЕРЕПЛАТЫ</span></h1>
                        <div class="es1__menu">
                            <a href="remont-kvartir-tseny/index.html" class="es1__menu_item lbl1"><span>Без предоплаты </span></a>
                            <a href="remont-kottedzhey-tseny/index.html" class="es1__menu_item lbl2"><span>Оформление в течение 15 минут</span></a>
                            <a href="remont-ofisov-tseny/index.html" class="es1__menu_item lbl3"><span>Срок – от 3 до 36 мес.</span></a>
    
                        </div>
    
                        <div class="text">Благодаря многолетнему сотрудничеству с банками «Альфа-Банк» и «Кредит Европа Банк», мы можем предложить Вам ВЫГОДНЫЕ УСЛОВИЯ ПО КРЕДИТОВАНИЮ</div>
                        
                        <div class="banks">
                            <img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/rasr_evrbank.png" alt="">
                            <img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/rasr_alfabank.png" alt="">
                        </div>    
                    </div>
                </div>
            </div>