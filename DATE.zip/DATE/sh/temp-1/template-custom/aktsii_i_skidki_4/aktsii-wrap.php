 <div class="aktsii-wrap">
           <div class="container">
               <h2>САМЫЕ ВЫГОДНЫЕ АКЦИИ НА ШКАФЫ</h2>
           </div> 
           
            <div class="action-item">
                <div class="container">
                    <div class="flex-container">
                        <div class="item-text">
                            <div class="h4">
                                <i>1</i>
                                <span>АКЦИЯ «<span>ФОТОПЕЧАТЬ</span> В ПОДАРОК»</span>
                            </div>
                            <p>Закажите шкаф и получите фотопечать с любым понравившимся изображением в подарок!</p>
                        </div>
                        <div class="item-img"><img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/aktsii-i-skidki-1.png" alt=""></div>
                    </div>
                </div>
            </div>
           
            <div class="action-item">
                <div class="container">
                    <div class="flex-container">
                        <div class="item-text">

                            <div class="h4">
                                <i>2</i>
                                <span>АКЦИЯ «<span>ЗЕРКАЛО НА ДВЕРЬ ШКАФА</span> В ПОДАРОК»</span>
                            </div>
                            <p>Закажите встроенный шкаф стоимостью более 25.000 руб. и получите в подарок зеркальную дверь (расположение – на Ваш выбор).</p>
                        

                        </div>
                        <div class="item-img"><img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/aktsii-i-skidki-2.png" alt=""></div>
                    </div>
                </div>
            </div>
            <div class="action-item">
                <div class="container">
                    <div class="flex-container">
                        <div class="item-text">
                            <div class="h4">
                                <i>3</i>
                                <span><span>ВЕРНЕМ</span> ДЕНЬГИ </span>
                            </div>
                            <p>Хотите вернуть часть затраченных на покупку шкафа средств? <br>
Рекомендуйте «Компанию» своим родным и друзьям и получайте возврат части денежных средств после их заказов!
</p>

                        </div>
                        <div class="item-img"><img style="transform: translateY(20px);" src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/aktsii-i-skidki-3.png" alt=""></div>

                    </div>
                </div>
            </div>


            <div class="action-item">
                <div class="container">
                    <div class="flex-container">
                        <div class="item-text">
                            <div class="h4">
                                <i>4</i>
                                <span><span>СКИДКА</span> ПРИ НАЛИЧИИ СОЦИАЛЬНОЙ КАРТЫ</span>
                            </div>
                            <p>Предъявите социальную карту при оформлении заказа на шкаф и получите дополнительную скидку 5%!</p>
                        </div>
                        
                        <div class="item-img"><img style="transform: translateY(3px);" src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/aktsii-i-skidki-4.png" alt=""></div>
                    </div>
                </div>
            </div>

        </div>