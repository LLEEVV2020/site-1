
        
          <div class="b-contact">
        <div class="container">
            <h2>
                КОГДА ЗАМЕРЩИК МОЖЕТ ПРИЕХАТЬ К ВАМ?
            </h2>

            <div class="b-contact_underzag">
                Если у Вас нет возможности посетить наш офис, наш специалист приедет к вам для консультации и замера абсолютно бесплатно*! В удобные для вас день и время! 
                
                *В радиусе 50 км <?php echo get_option('my_city_ot'); ?>.
            </div>

            <div class="b-contact__cityform">
                <div class="row">

                        <script>
                            var anyCityInInput = "yes";
                        </script>
                                                

                   
                    <div class="col-md-12 flex-container">
                        <div class="b_contact_input_city">
                            <input type="text" id="call_zamershik_name_city" placeholder="Ваш город">
                        </div>
                        <div class="b_contact_but_city"  data-toggle="modal" data-target="#kupitDeshevle">УЗНАТЬ
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /.b-contact -->