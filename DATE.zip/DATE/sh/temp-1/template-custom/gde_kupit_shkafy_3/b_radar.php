<div class="b-radar">
        <div class="b-radar_bg" style="background: url(//<?php echo $_SERVER['SERVER_NAME']; ?>/city_include/<?php echo get_option('my_city_lat'); ?>/radar.jpg) no-repeat center center;">
            <div class="b-radar_active">
            </div>
        </div>
    </div>
    <!-- /.b-radar -->