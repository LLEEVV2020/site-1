
        <div class="es1_otzivy_bg">
            <div class="container">



                <div class="es1_otzivy_item">

                    <div class="es1_otzivy_item__img">
                        <img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/otziv1.png" alt="СВЕТЛАНА - фото" >
                    </div>


                    <div class="es1_otzivy_item__right">
                        <div class="es1_otzivy_item__otztext">
                            <div class="es1_otzivy_item__otztext__name">СВЕТЛАНА <div
                                    class="es1_otzivy_item__otztext__city">Г. МОСКВА</div>
                            </div>

                            <div class="es1_otzivy_item__otztext__text">Нужен был встроенный шкаф в детскую комнату для девочки и желательно
                                розового цвета!
                                Не все компании этим занимаются, но компания
                                “Шкафы цены” помогла мне в этом вопросе
                                и выполнила мое пожелание
                                и по цвету, и по размеру, и по дизайну! Спасибо им большое!
                            </div>
                        </div>
                        <div class="flex-wrap">
                            <div class="es1_otzivy_item__star">
                                <span>Оценка работы компании</span>
                                <nobr>
    
                                    <img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/star.png" alt="" />
                                    <img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/star.png" alt="" />
                                    <img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/star.png" alt="" />
                                    <img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/star.png" alt="" />
                                    <img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/star.png" alt="" />
                                </nobr>
                            </div>
    
                            <div class="es1_otzivy_item__rek">
                                Буду рекомендовать
                                <img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/rek_act.png" alt="" />
                            </div>
                        </div>
                        


                    </div>
                </div>

               
                <div class="es1_otzivy_item">

                    <div class="es1_otzivy_item__img">
                        <img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/otziv1.png" alt="СВЕТЛАНА - фото" >
                    </div>


                    <div class="es1_otzivy_item__right">
                        <div class="es1_otzivy_item__otztext">
                            <div class="es1_otzivy_item__otztext__name">СВЕТЛАНА <div
                                    class="es1_otzivy_item__otztext__city">Г. МОСКВА</div>
                            </div>

                            <div class="es1_otzivy_item__otztext__text">Нужен был встроенный шкаф в детскую комнату для девочки и желательно
                                розового цвета!
                                Не все компании этим занимаются, но компания
                                “Шкафы цены” помогла мне в этом вопросе
                                и выполнила мое пожелание
                                и по цвету, и по размеру, и по дизайну! Спасибо им большое!
                            </div>
                        </div>
                        <div class="flex-wrap">
                            <div class="es1_otzivy_item__star">
                                <span>Оценка работы компании</span>
                                <nobr>
    
                                    <img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/star.png" alt="" />
                                    <img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/star.png" alt="" />
                                    <img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/star.png" alt="" />
                                    <img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/star.png" alt="" />
                                    <img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/star.png" alt="" />
                                </nobr>
                            </div>
    
                            <div class="es1_otzivy_item__rek">
                                Буду рекомендовать
                                <img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/rek_act.png" alt="" />
                            </div>
                        </div>
                        


                    </div>
                </div>  
                
                <div class="es1_otzivy_item">

                    <div class="es1_otzivy_item__img">
                        <img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/otziv1.png" alt="СВЕТЛАНА - фото" >
                    </div>


                    <div class="es1_otzivy_item__right">
                        <div class="es1_otzivy_item__otztext">
                            <div class="es1_otzivy_item__otztext__name">СВЕТЛАНА <div
                                    class="es1_otzivy_item__otztext__city">Г. МОСКВА</div>
                            </div>

                            <div class="es1_otzivy_item__otztext__text">Нужен был встроенный шкаф в детскую комнату для девочки и желательно
                                розового цвета!
                                Не все компании этим занимаются, но компания
                                “Шкафы цены” помогла мне в этом вопросе
                                и выполнила мое пожелание
                                и по цвету, и по размеру, и по дизайну! Спасибо им большое!
                            </div>
                        </div>
                        <div class="flex-wrap">
                            <div class="es1_otzivy_item__star">
                                <span>Оценка работы компании</span>
                                <nobr>
    
                                    <img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/star.png" alt="" />
                                    <img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/star.png" alt="" />
                                    <img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/star.png" alt="" />
                                    <img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/star.png" alt="" />
                                    <img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/star.png" alt="" />
                                </nobr>
                            </div>
    
                            <div class="es1_otzivy_item__rek">
                                Буду рекомендовать
                                <img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/rek_act.png" alt="" />
                            </div>
                        </div>
                        


                    </div>
                </div>

            </div>
        </div><!-- /.container -->