  
  <link href="//<?php echo $_SERVER['SERVER_NAME']; ?>/css/zoom-showcase.css" rel="stylesheet"><link rel="stylesheet" href="zoom-showcase.css">
  <!-- es16_bg20 -->
  <div class="es16_bg">
            <div class="h2">
                Ремонты, выполненные в 2019 году
            </div>
            <div class="thanky">
                <div class="zoom-gallery" id="zoom-instance-1" style="margin: 0px auto;  height: 397px;">
                    <img width="55" alt="preloader" src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/preloader.gif" height="18" class="preloader">
                    <ul>


                        <li title="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/es16_bg-1.jpg">
                            <ul class="align-left">
                                <li class="10x208"
                                    style="background-color: none; color: #464545; font-size:2.4em; line-height:30px; height:auto;">
                                    Зеркальный шкаф. <br /><span>11.800 </span>р.<br />
                                    <div class="">Разработан и установлен в течение <span>3х дней</span>!</div>
                                </li>
                            </ul>
                        </li>


                        <li title="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/es16_bg-2.jpg">
                            <ul class="align-left">
                                <li class="10x208"
                                    style="background-color: none; color: #464545; font-size:2.4em; line-height:30px; height:auto;">
                                    Зеркальный шкаф. <br /><span>11.800 </span>р.<br />
                                    <div class="">Разработан и установлен в течение <span>3х дней</span>!</div>
                                </li>
                            </ul>
                        </li>





                        <li title="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/1.jpg">
                            <ul class="align-left">
                                <li class="10x208"
                                    style="background-color: none; color: #464545; font-size:2.4em; line-height:30px; height:auto;">
                                    Зеркальный шкаф. <br /><span>11.800 </span>р.<br />
                                    <div class="">Разработан и установлен в течение <span>3х дней</span>!</div>
                                </li>
                            </ul>
                        </li>


                        <li title="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/es16_bg-1.jpg">
                            <ul class="align-left">
                                <li class="10x208"
                                    style="background-color: none; color: #464545; font-size:2.4em; line-height:30px; height:auto;">
                                    Зеркальный шкаф. <br /><span>11.800 </span>р.<br />
                                    <div class="">Разработан и установлен в течение <span>3х дней</span>!</div>
                                </li>
                            </ul>
                        </li>


                        <li title="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/es16_bg-2.jpg">
                            <ul class="align-left">
                                <li class="10x208"
                                    style="background-color: none; color: #464545; font-size:2.4em; line-height:30px; height:auto;">
                                    Зеркальный шкаф. <br /><span>11.800 </span>р.<br />
                                    <div class="">Разработан и установлен в течение <span>3х дней</span>!</div>
                                </li>
                            </ul>
                        </li>


                        <li title="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/1.jpg">
                            <ul class="align-left">
                                <li class="10x208"
                                    style="background-color: none; color: #464545; font-size:2.4em; line-height:30px; height:auto;">
                                    Зеркальный шкаф. <br /><span>11.800 </span>р.<br />
                                    <div class="">Разработан и установлен в течение <span>3х дней</span>!</div>
                                </li>
                            </ul>
                        </li>

                    </ul>
                    <!-- If JavaScript is disabled, we'll just display the first image -->
                </div>

                <a id="thanky-left-button" href="#"></a> <a id="thanky-right-button" href="#"></a>
            </div>



            <div class="onmobile">
                <img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/es16_bg-2.jpg" alt="">
                <div class="onmobile-info-text">
                    Ремонт коттеджа стоимостью:&nbsp;<span>27&nbsp;300&nbsp;р.</span>
                </div>
            </div>
        </div>
         <!-- es16_bg20 -->