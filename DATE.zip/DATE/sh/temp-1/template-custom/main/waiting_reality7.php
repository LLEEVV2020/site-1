 <!-- b-sms_bg -->
<div class="waiting_reality7 b-sms_bg">
    <div class="container ">
        <div class="flex-container">

            <div class="b-sms__text">
               ОЖИДАНИЕ vs РЕАЛЬНОСТЬ.  100% СОВПАДЕНИЕ!
            </div>

            <div class="flex-block">
                <div class="item img-block">
                    <img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/b_sms_phone3.png" alt="">
                    <div class="b-beforeAfter__item">
                        <div class="b-beforeAfter__item_slider">
                        <div class="twentytwenty-container">
                            <img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/do2.jpg"/>
                            <img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/posle2.jpg"/>
                        </div>

                        </div>
                        <div class="b-beforeAfter__info" style="display: none;">
                            <div class="b-beforeAfter__info_item">
                                Срок: <span class="yellow">12</span> дней
                            </div>
                            <div class="b-beforeAfter__info_item">
                                Цена: <span class="red">38 100</span> р.
                            </div>
                        </div>
                    </div>
                </div>
                <div class="item text-block">

                    <div class="b-sms__undertext">
                        Дизайн-проект шкафа
                    </div>
                    <div class="b-sms__undertext">
                        <span class="b-vid-remonta__price_old">700</span>
                        <span>=</span>
                        <span>0</span>
                        
                    <button class="red-button"  data-toggle="modal" data-target="#kupitDeshevle">ХОЧУ!</button>
                    </div>


                    <p>Звоните сейчас и получите самое выгодное предложение! Дешевле не найдете!</p>
                </div>

            </div>


        </div>
    </div>
    <!-- /.container -->
</div>
<!-- /.b-sms_bg -->