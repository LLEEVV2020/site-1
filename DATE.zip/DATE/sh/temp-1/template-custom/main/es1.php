<div class="es1 _main">
    <div class="container">
        <div class="es1__pict"></div>
        <div class="es1__block">
            <h2><span>Шкафы </span></h2>
            <h1 ><span >  по низким ценам</span></h1>
            <div class="es1__menu">
                <a href="#b-vid" class="es1__menu_item lbl1"><span>ШКАФЫ-КУПЕ</span></a>
                <a href="#b-vid" class="es1__menu_item lbl2"><span>ВСТРОЕННЫЕ ШКАФЫ</span></a>
                <a href="#b-vid" class="es1__menu_item lbl3"><span>УГЛОВЫЕ ШКАФЫ</span></a>

            </div>

            <div class="es1-flex-wrap">
                <div class="es1_skidka__block">
                    <div class="es1_skidka__block_item">
                        <div class="es1_7day">Только 7 дней!</div>
                        <div class="es1-skidka">СКИДКА ДО</div>
                    </div>
                    <div class="es1_sale">63% </div>
                </div>

                <div class="b-top__zamer" data-toggle="modal" data-target="#kupitDeshevle">
                    <div class="b-top__zamer_ruler "></div>
                    <div class="b-top__zamer_txt"><span>БЕСПЛАТНЫЙ</span><br>
                        выезд замерщика</div>
                </div>
            </div>


        </div>
    </div>
</div>