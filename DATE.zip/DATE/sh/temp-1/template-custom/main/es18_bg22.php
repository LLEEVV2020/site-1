<div class="es18_bg">
            <div class="container">

                <div class="flex-container">

                    <h3>ШКАФЫ И КУХНИ ПО НИЗКИМ ЦЕНАМ </h3>
                    <i class="angle-angle"></i>
                    <a href="//<?php echo $_SERVER['SERVER_NAME']; ?>">Шкафы цены</a>
                    <a href="//<?php echo $_SERVER['SERVER_NAME']; ?>">Кухни цены</a>

                </div>


            </div>

        </div><!-- /.es18_bg -->