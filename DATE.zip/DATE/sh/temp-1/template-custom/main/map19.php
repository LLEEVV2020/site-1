   <div class="map-wrapper">
            <div id="BX_YMAP_officemap" class="bx-yandex-map" style="height: 600px; width: 100%;">
                <!--<script src="//api-maps.yandex.ru/2.1/?lang=ru_RU" type="text/javascript"></script>
                <script> ymapload(); </script>-->
                <script type="text/javascript" charset="utf-8" async src="https://api-maps.yandex.ru/services/constructor/1.0/js/?um=constructor%3A2de84570b790e894c8b15f3aaa049ee7179a3113bd9a0e7229884622e936cb86&amp;width=100%25&amp;height=600&amp;lang=ru_RU&amp;scroll=true"></script>
            </div>
        </div>